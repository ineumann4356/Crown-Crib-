const events = {
  1:{name:"Tempo Surge", text:"Runs upgraded: 3=4 pts, 4=6 pts, 5=8 pts, +2 after 5."},
  2:{name:"Golden Fifteens", text:"All 15s score 3 points."},
  3:{name:"Crowned Pairs", text:"Pair=3, 3 of a Kind=9, 4 of a Kind=16, 5 of a Kind=25."},
  4:{name:"Royal Rotation", text:"After Starter reveal: pass 1 card of your choice left."},
  5:{name:"Kingdom Tax", text:"After Starter reveal: 2 cards to shared pool, dealer shuffles, give 2 back."},
  6:{name:"Public Shame", text:"After Starter reveal: player on left reveals 1 card, discard bottom, replace from top."}
};
const colorMap = ["#9f2c2c","#2c5f9f","#2d7a3d","#b78928"];
const defaultNames = ["Red Crown","Blue Crown","Green Crown","Gold Crown"];
let state = {players:[], goal:121, selected:0, dealer:0, currentEvent:null, history:[]};

const $ = id => document.getElementById(id);
const modeEl = $("mode"), goalEl = $("goal"), nameInputs = $("nameInputs");

function countForMode(mode){ return mode === "team" ? 2 : Number(mode); }
function renderNameInputs(){
  const count = countForMode(modeEl.value);
  nameInputs.innerHTML = "";
  for(let i=0;i<count;i++){
    const lab = document.createElement("label");
    lab.textContent = modeEl.value === "team" ? (i===0 ? "Team 1" : "Team 2") : `Player ${i+1}`;
    const inp = document.createElement("input");
    inp.id = `name${i}`;
    inp.value = modeEl.value === "team" ? (i===0 ? "Team Crown" : "Team Shield") : defaultNames[i];
    lab.appendChild(inp);
    nameInputs.appendChild(lab);
  }
}
modeEl.addEventListener("change", renderNameInputs);
renderNameInputs();

function save(){ localStorage.setItem("crownCribV2", JSON.stringify(state)); }
function load(){
  try{
    const raw = localStorage.getItem("crownCribV2");
    if(raw){ state = JSON.parse(raw); renderAll(); }
  }catch(e){}
}

function start(){
  const count = countForMode(modeEl.value);
  state.goal = Number(goalEl.value);
  state.players = [];
  for(let i=0;i<count;i++){
    const name = $(`name${i}`).value.trim() || defaultNames[i];
    state.players.push({name, score:0, color:colorMap[i]});
  }
  state.selected = 0; state.dealer = 0; state.currentEvent = null; state.history = [];
  save(); renderAll();
}
$("startBtn").addEventListener("click", start);

function renderEvents(){
  const grid = $("eventGrid");
  grid.innerHTML = "";
  [1,2,3,4,5,6].forEach(n=>{
    const e = events[n];
    const btn = document.createElement("button");
    btn.className = "event" + (state.currentEvent === n ? " selected" : "");
    btn.innerHTML = `<strong>${n} ${e.name}</strong><span>${e.text}</span>`;
    btn.onclick = () => { state.currentEvent = n; state.history.push(`Event Die: ${n} ${e.name}`); save(); renderAll(); };
    grid.appendChild(btn);
  });
  const current = $("currentEvent");
  if(state.currentEvent){
    const e = events[state.currentEvent];
    current.innerHTML = `<b>${state.currentEvent} ${e.name}</b><span>${e.text}</span>`;
  } else {
    current.innerHTML = `<b>No Event Selected</b><span>Tap the event rolled this round.</span>`;
  }
}
$("clearEventBtn").addEventListener("click",()=>{state.currentEvent=null;save();renderAll();});

function renderScores(){
  $("gamePanel").classList.toggle("hidden", state.players.length === 0);
  $("goalView").textContent = state.goal;
  const box = $("scoreCards");
  box.innerHTML = "";
  state.players.forEach((p,i)=>{
    const card = document.createElement("div");
    card.className = "score-card" + (state.selected === i ? " selected" : "");
    card.onclick = ()=>{state.selected=i;save();renderAll();};
    const pct = Math.min(100, p.score/state.goal*100);
    card.innerHTML = `
      <div class="score-top">
        <span class="house-dot" style="background:${p.color}"></span>
        <span class="name">${p.name}</span>
        ${state.dealer===i ? '<span class="dealer">Dealer</span>' : ''}
      </div>
      <div class="score">${p.score}</div>
      <div class="progress"><div class="bar" style="width:${pct}%"></div></div>
      ${p.score >= state.goal ? '<div class="victory">👑 Victory!</div>' : ''}
    `;
    box.appendChild(card);
  });
}

function add(points, label){
  if(!state.players.length) return;
  const p = state.players[state.selected];
  const old = p.score;
  p.score = Math.max(0, p.score + points);
  state.history.push(`${p.name}: ${old} → ${p.score} (${points>=0?"+":""}${points}${label?`, ${label}`:""})`);
  save(); renderAll();
}
document.querySelectorAll("[data-add]").forEach(b=>b.onclick=()=>add(Number(b.dataset.add)));

const helperBase = {
  "15":2, "31":2, "go":1, "pair":2, "trips":6, "quads":12, "run3":3, "run4":4, "run5":5, "nobs":1, "heels":2
};
document.querySelectorAll("[data-helper]").forEach(b=>{
  b.onclick=()=>{
    let key=b.dataset.helper, pts=helperBase[key], label=b.textContent.trim();
    if(state.currentEvent===1 && key==="run3") pts=4;
    if(state.currentEvent===1 && key==="run4") pts=6;
    if(state.currentEvent===1 && key==="run5") pts=8;
    if(state.currentEvent===2 && key==="15") pts=3;
    if(state.currentEvent===3 && key==="pair") pts=3;
    if(state.currentEvent===3 && key==="trips") pts=9;
    if(state.currentEvent===3 && key==="quads") pts=16;
    add(pts, label);
  };
});

$("customBtn").onclick=()=>{
  const val = Number($("customAmount").value);
  if(Number.isFinite(val) && val !== 0){ add(val, "custom"); $("customAmount").value=""; }
};
$("undoBtn").onclick=()=>{
  const last = state.history.pop(); if(!last) return;
  const m = last.match(/^(.*): (\d+) → (\d+) \(([+-]?\d+)/);
  if(m){
    const p = state.players.find(x=>x.name===m[1]);
    if(p) p.score = Number(m[2]);
  }
  save(); renderAll();
};
$("nextDealerBtn").onclick=()=>{
  if(!state.players.length) return;
  state.dealer = (state.dealer + 1) % state.players.length;
  state.history.push(`Dealer: ${state.players[state.dealer].name}`);
  save(); renderAll();
};
$("resetBtn").onclick=()=>{
  if(!confirm("Reset scores and history?")) return;
  state.players.forEach(p=>p.score=0);
  state.history=[]; state.currentEvent=null; state.dealer=0; state.selected=0;
  save(); renderAll();
};

function renderHistory(){
  const h = $("history");
  h.innerHTML = "";
  state.history.slice().reverse().forEach(x=>{
    const li=document.createElement("li"); li.textContent=x; h.appendChild(li);
  });
}
function renderAll(){ renderScores(); renderEvents(); renderHistory(); }
load();
renderEvents();

if("serviceWorker" in navigator){ navigator.serviceWorker.register("sw.js").catch(()=>{}); }
